package com.bridgelabz.todosecond.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatTextView;

import com.bridgelabz.todosecond.R;

public class Result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        AppCompatTextView textView=(AppCompatTextView)findViewById(R.id.resulttextView);
        Intent intent=getIntent();
        Bundle bundle=intent.getBundleExtra("name");

        if(bundle!=null)
        {

            String data =(String) bundle.get("text");
            textView.setText(data);
        }
    }
}
