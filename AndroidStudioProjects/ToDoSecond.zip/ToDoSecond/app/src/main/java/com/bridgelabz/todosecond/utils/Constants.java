package com.bridgelabz.todosecond.utils;


public class Constants {
    public static int sleep=2000;
    public static String keys="vinod";
    public static String values="";
}
