package bridgelabz.bridgelogin;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    EditText email;
    EditText pass;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        email = (EditText) findViewById(R.id.editText_regemail);
        pass = (EditText) findViewById(R.id.editText_regpass);
        btn = (Button) findViewById(R.id.button_reglog);

    }

    public void save(View view)
    {
        SharedPreferences sharedPreferences = getSharedPreferences("vinod", Context.MODE_PRIVATE);
        SharedPreferences.Editor sEditor = sharedPreferences.edit();

        sEditor.putString("email", email.getText().toString());
        sEditor.putString("password", pass.getText().toString());
        sEditor.commit();
        Intent intent=new Intent(this,LoginActivity.class);
        startActivity(intent);
        Toast.makeText(Register.this, "Registration Successful", Toast.LENGTH_SHORT).show();



    }
}