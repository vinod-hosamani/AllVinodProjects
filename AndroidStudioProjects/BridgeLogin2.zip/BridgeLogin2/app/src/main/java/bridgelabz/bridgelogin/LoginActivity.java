package bridgelabz.bridgelogin;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
     private static EditText e1,e2;
     private static Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        onButton();
    }
    public void onButton(){
        SharedPreferences sharedPreferences = getSharedPreferences("vinod", Context.MODE_PRIVATE);
        e1=(EditText)findViewById(R.id.editText_email);
        e2=(EditText)findViewById(R.id.editText_pass);
        btn=(Button)findViewById(R.id.button_login);
       final String email=sharedPreferences.getString("email","s");
       final String password=sharedPreferences.getString("password","s");
        btn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        if(e1.getText().toString().equalsIgnoreCase(email) &&
                                e2.getText().toString().equals(password) )
                        {
                            Toast.makeText(LoginActivity.this, "user and password is correct",
                                    Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this,User.class);
                            startActivity(intent);
                        }
                            else
                            {
                                Toast.makeText(LoginActivity.this,"user and password is not  correct",
                                        Toast.LENGTH_SHORT).show();

                            }
                        }
                    });
    }
}
